function showNotification(type, msg) {
  alert(`🔔 [${type.toUpperCase()}] ${msg}`);
}