function setRecoveryQuestion(answer) {
  const nick = localStorage.getItem('retrocast_profile');
  localStorage.setItem('recover_' + nick, answer);
}

function checkRecovery(answer) {
  const nick = localStorage.getItem('retrocast_profile');
  return localStorage.getItem('recover_' + nick) === answer;
}