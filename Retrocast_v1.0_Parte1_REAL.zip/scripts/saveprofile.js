function saveProfileData(profile, data) {
  localStorage.setItem(`profiledata_${profile}`, JSON.stringify(data));
}