function enterSpectatorMode(match) {
  alert(`👁️ Assistindo partida: ${match.player1} vs ${match.player2}`);
}