function showTrophy(name, type = 'normal') {
  const effect = type === 'gold' ? '✨ Troféu Dourado!' : '🏅 Troféu desbloqueado';
  alert(effect + ' – ' + name);
}