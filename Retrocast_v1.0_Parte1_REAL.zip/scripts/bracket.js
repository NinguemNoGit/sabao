function generateBracket(players) {
  let rounds = Math.ceil(Math.log2(players.length));
  let bracket = { players, rounds, matches: [] };
  localStorage.setItem('tournament_bracket', JSON.stringify(bracket));
  alert('🏆 Torneio com ' + players.length + ' jogadores criado!');
}