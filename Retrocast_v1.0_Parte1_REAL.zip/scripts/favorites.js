/**
 * Adiciona ou remove um jogo da lista de favoritos do perfil.
 * @param {string} profile - Nome do perfil (ex: "player1")
 * @param {string} game - Nome do jogo (ex: "Super Mario World")
 */
function toggleFavorite(profile, game) {
    const key = 'fav_' + profile;
    let favs = [];

    // Tenta carregar os favoritos do localStorage
    try {
        const stored = localStorage.getItem(key);
        favs = stored ? JSON.parse(stored) : [];
    } catch (e) {
        console.warn(`Erro ao ler favoritos de "${profile}"`, e);
        favs = [];
    }

    // Garante que seja um array
    if (!Array.isArray(favs)) {
        favs = [];
    }

    // Verifica se o jogo já está nos favoritos
    const isFavorite = favs.includes(game);

    // Atualiza a lista
    if (isFavorite) {
        favs = favs.filter(g => g !== game); // Remove
    } else {
        favs.push(game); // Adiciona
    }

    // Salva de volta no localStorage
    try {
        localStorage.setItem(key, JSON.stringify(favs));
    } catch (e) {
        console.error("Não foi possível salvar os favoritos.", e);
        alert("Erro ao salvar. Sua lista de favoritos pode estar muito grande.");
        return;
    }

    // Feedback visual ao usuário
    if (isFavorite) {
        alert(`❌ "${game}" foi removido dos seus favoritos.`);
    } else {
        alert(`✅ "${game}" foi adicionado aos seus favoritos.`);
    }
}