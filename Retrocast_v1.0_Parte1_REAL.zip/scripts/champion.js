function declareChampion(name) {
  alert(`👑 ${name} venceu o torneio! ✨ Troféu dourado entregue.`);
}