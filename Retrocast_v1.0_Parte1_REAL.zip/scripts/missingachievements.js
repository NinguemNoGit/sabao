function showMissingAchievements(profile) {
  alert(`🎯 Mostrando jogos com conquistas faltantes para ${profile}`);
}