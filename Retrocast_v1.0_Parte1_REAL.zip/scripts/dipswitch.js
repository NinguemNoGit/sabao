function setDipSwitch(game, option, value) {
  const key = `dips_${game}`;
  let config = JSON.parse(localStorage.getItem(key) || '{}');
  config[option] = value;
  localStorage.setItem(key, JSON.stringify(config));
}