function login(nick) {
  if (!nick) return alert('Nome de perfil inválido');
  localStorage.setItem('retrocast_profile', nick);
  alert('👤 Bem-vindo, ' + nick + '!');
}