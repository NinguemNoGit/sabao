function enterLiveView(player1, player2) {
  alert(`👁️ Assistindo agora: ${player1} vs ${player2}`);
}