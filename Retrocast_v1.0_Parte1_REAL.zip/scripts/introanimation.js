function playIntro() {
  alert('✨ Animação de entrada ativada!');
}