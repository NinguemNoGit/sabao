function showAchievements(profile) {
    const key = 'achievements_' + profile;
    let achievements = JSON.parse(localStorage.getItem(key)) || [];

    if (!Array.isArray(achievements)) {
        achievements = [];
    }

    let html = `<h2>🎖️ Conquistas Desbloqueadas</h2>`;
    if (achievements.length === 0) {
        html += `<p>Você ainda não desbloqueou nenhuma conquista.</p>`;
    } else {
        html += `<ul style="list-style: none; padding-left: 0;">`;
        achievements.forEach(ach => {
            html += `<li style="margin: 8px 0;">✅ ${ach}</li>`;
        });
        html += `</ul>`;
    }

    document.getElementById("menuContent").innerHTML = html;
}