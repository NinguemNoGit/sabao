function showLeaderboard() {
  alert('🏆 Leaderboard: Top jogadores exibidos com elo e estrelas');
}