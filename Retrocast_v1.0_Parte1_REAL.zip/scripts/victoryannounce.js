function announceVictory(player) {
  alert(`🎉 Vitória épica de ${player}! Notificação para todos os jogadores.`);
}