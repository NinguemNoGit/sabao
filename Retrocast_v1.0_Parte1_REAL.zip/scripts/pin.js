function setPin(pin) {
  const nick = localStorage.getItem('retrocast_profile');
  if (!nick) return;
  localStorage.setItem('pin_' + nick, pin);
  alert('🔒 PIN cadastrado com sucesso!');
}

function checkPin(pin) {
  const nick = localStorage.getItem('retrocast_profile');
  return localStorage.getItem('pin_' + nick) === pin;
}