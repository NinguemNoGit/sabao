function welcomePlayer() {
  const nick = localStorage.getItem('retrocast_profile');
  if (nick) alert('👋 Olá, ' + nick + '! Pronto para jogar?');
}