function startTournament(players) {
  let bracket = players.slice(0, 8).map((p, i) => ({ id: i + 1, name: p, wins: 0 }));
  localStorage.setItem('retrocast_bracket', JSON.stringify(bracket));
  alert('🏆 Torneio iniciado com ' + bracket.length + ' jogadores!');
}