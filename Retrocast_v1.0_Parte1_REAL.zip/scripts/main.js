// === Gerenciamento de Perfil ===
function selectProfile() {
    const newProfile = prompt("Digite seu nome de perfil:", getCurrentProfile());
    if (newProfile && newProfile.trim() !== "") {
        localStorage.setItem("currentProfile", newProfile.trim());
        updateProfileDisplay();
        showAchievements(newProfile.trim());
    }
}

function getCurrentProfile() {
    return localStorage.getItem("currentProfile") || "Jogador";
}

function updateProfileDisplay() {
    const profileName = getCurrentProfile();
    document.getElementById("currentProfile").innerText = `👤 Perfil: ${profileName}`;
}

// === Menu Overlay ===
function openMenu(menu) {
    const overlay = document.getElementById("menuOverlay");
    const content = document.getElementById("menuContent");

    switch (menu) {
        case 'favorites':
            content.innerHTML = "<h2>Favoritos</h2><p>Conteúdo dos favoritos...</p>";
            break;

        case 'netplay':
            content.innerHTML = "<h2>Netplay</h2><p>Jogue online com amigos!</p>";
            break;

        case 'achievements':
            showAchievements(getCurrentProfile()); // Completa a chamada da função
            break;

        case 'controls':
            content.innerHTML = "<h2>Controles</h2><p>Configuração dos controles.</p>";
            break;

        case 'settings':
            content.innerHTML = "<h2>Configurações</h2><p>Ajuste volume, vídeo, etc.</p>";
            break;

        default:
            content.innerHTML = "<h2>Erro</h2><p>Menu não encontrado.</p>";
    }

    overlay.style.display = "flex";
}

function closeMenu() {
    document.getElementById("menuOverlay").style.display = "none";
}