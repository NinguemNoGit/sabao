function toggleNeoGeoMode(mode) {
  localStorage.setItem('neogeo_mode', mode);
  alert(`🕹️ Neo Geo agora em modo: ${mode}`);
}