function trackAchievement(name, progress) {
  alert(`🏅 ${name}: ${progress}% completo`);
}