function syncCloud() {
  alert('☁️ Progresso salvo com sucesso na nuvem!');
}