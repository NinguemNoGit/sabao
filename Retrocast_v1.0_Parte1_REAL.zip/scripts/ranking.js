function updateRanking(profile, score) {
  let data = JSON.parse(localStorage.getItem('ranking') || '{}');
  data[profile] = (data[profile] || 0) + score;
  localStorage.setItem('ranking', JSON.stringify(data));
  alert(`🏆 Pontuação de ${profile}: ${data[profile]} pontos!`);
}