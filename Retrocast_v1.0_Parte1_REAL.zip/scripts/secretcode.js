let code = '', target = '↑↑↓↓←→←→BA';
document.addEventListener('keydown', e => {
  code += e.key.toUpperCase();
  if (code.length > target.length) code = code.slice(-target.length);
  if (code === target) alert('✅ Salvamento do sistema ativado!');
});