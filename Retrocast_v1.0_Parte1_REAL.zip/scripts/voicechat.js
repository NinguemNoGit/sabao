function toggleVoiceChat() {
  const status = localStorage.getItem('voicechat') === 'on';
  localStorage.setItem('voicechat', status ? 'off' : 'on');
  alert('🎙️ Chat de voz ' + (status ? 'desativado' : 'ativado'));
}