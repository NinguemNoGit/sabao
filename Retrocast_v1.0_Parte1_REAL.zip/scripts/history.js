function saveHistory(profile, game) {
  const key = 'history_' + profile;
  let list = JSON.parse(localStorage.getItem(key) || '[]');
  list.unshift(game);
  localStorage.setItem(key, JSON.stringify(list.slice(0, 10)));
}