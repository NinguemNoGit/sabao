function applyShader(shaderName) {
  alert(`🎨 Filtro aplicado: ${shaderName}`);
  localStorage.setItem('selected_shader', shaderName);
}