function loadProfile() {
  return localStorage.getItem('retrocast_profile') || 'Convidado';
}