function showControls(profile) {
  alert(`🎮 Controles de ${profile} carregados e exibidos.`);
}