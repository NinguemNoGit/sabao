function playSoundFX(type) {
  if (type === 'move') new Audio('audio/move.ogg').play();
  if (type === 'select') new Audio('audio/select.ogg').play();
}