// JavaScript da animacao de introducao Retrocast
console.log('Intro effect loaded');