// Shader: lcd_pixel.glsl
// Simulação de filtro visual