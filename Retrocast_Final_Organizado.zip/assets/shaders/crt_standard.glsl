// Shader: crt_standard.glsl
// Simulação de filtro visual