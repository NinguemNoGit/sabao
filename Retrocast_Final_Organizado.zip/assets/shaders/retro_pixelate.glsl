// Shader: retro_pixelate.glsl
// Simulação de filtro visual