// Shader: sharp_bilinear.glsl
// Simulação de filtro visual