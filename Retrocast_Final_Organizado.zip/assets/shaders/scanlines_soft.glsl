// Shader: scanlines_soft.glsl
// Simulação de filtro visual