// Script de controle de perfis Retrocast
let profile = {};