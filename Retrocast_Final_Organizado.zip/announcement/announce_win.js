// Script que exibe anúncio de vitória em tempo real
function showVictory(player) { console.log(player + ' venceu!'); }