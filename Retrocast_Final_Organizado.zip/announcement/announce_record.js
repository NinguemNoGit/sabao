// Script que exibe quebra de recorde
function showRecord(player, score) { console.log(player + ' fez um novo recorde: ' + score); }