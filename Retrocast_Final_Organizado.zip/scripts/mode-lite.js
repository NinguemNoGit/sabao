// Retrocast Modo Lite Automático
(function(){
  const isWeakDevice = /TV|Box|Android 5|QuadCore|Smart/i.test(navigator.userAgent);
  if(isWeakDevice){
    localStorage.setItem('retrocast_lite_mode', 'on');
    console.log("Modo Lite ativado automaticamente.");
  }
})();