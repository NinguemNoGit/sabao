// Script de detecção de hardware e aplicação de shader
