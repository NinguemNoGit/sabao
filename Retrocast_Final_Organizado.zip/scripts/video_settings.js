// Código JS do menu de resolução e gráficos Retrocast
