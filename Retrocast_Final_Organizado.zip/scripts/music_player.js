
const musicPlaylist = [
    { name: "Retro Theme Intro", url: "https://files.catbox.moe/6q6gbb.mp3" },
    { name: "Zelda Lofi Chill", url: "https://files.catbox.moe/egm4lz.mp3" },
    { name: "Sonic Green Hill Remix", url: "https://files.catbox.moe/91i9ur.mp3" },
    { name: "Castlevania Synthwave", url: "https://files.catbox.moe/xr7q9e.mp3" },
    { name: "Street Fighter Ken Stage", url: "https://files.catbox.moe/vk8znf.mp3" }
];

let currentTrack = 0;
let audio = new Audio();
audio.src = musicPlaylist[currentTrack].url;
audio.loop = false;
audio.volume = 0.7;
audio.play();

audio.addEventListener("ended", () => {
    currentTrack = (currentTrack + 1) % musicPlaylist.length;
    audio.src = musicPlaylist[currentTrack].url;
    audio.play();
    showNowPlaying();
});

function toggleMusic() {
    if (audio.paused) {
        audio.play();
        showNowPlaying();
    } else {
        audio.pause();
    }
}

function showNowPlaying() {
    const existing = document.getElementById("nowPlaying");
    if (existing) existing.remove();

    const msg = document.createElement("div");
    msg.id = "nowPlaying";
    msg.innerText = "🎵 Agora tocando: " + musicPlaylist[currentTrack].name;
    msg.style.position = "fixed";
    msg.style.bottom = "10px";
    msg.style.right = "10px";
    msg.style.background = "rgba(0,0,0,0.7)";
    msg.style.color = "white";
    msg.style.padding = "5px 10px";
    msg.style.borderRadius = "8px";
    msg.style.zIndex = "9999";
    document.body.appendChild(msg);

    setTimeout(() => msg.remove(), 5000);
}

// Botão para controle
const btn = document.createElement("button");
btn.innerText = "🎵 Música";
btn.onclick = toggleMusic;
btn.style.position = "fixed";
btn.style.top = "10px";
btn.style.right = "10px";
btn.style.zIndex = "9999";
document.body.appendChild(btn);

showNowPlaying();
