// Core fbaneo.js - Emulador compatível com 60 FPS e Netplay para Retrocast
